# Linkedin-scrapper
Gets data from Linkedin Users and stores in Google Sheets

This scrapper exists to access Linkedin user skills and profiles

# Client_secret.json file
Create a API from https://developers.google.com/sheets/api for Google spreadsheet
and download the json file from there

# config.txt
first line: Linkedin mail id

second line: Linkedin Password

# spreadsheet
This code will always check the first column only for usernames/pflinks, and then will fill the details in the matchin row
